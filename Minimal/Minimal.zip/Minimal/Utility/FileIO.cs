﻿// Author: Kevin Rucker
// License: BSD 3-Clause
// Copyright (c) 2014, Kevin Rucker
// All rights reserved.

// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice,
//    this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors
//    may be used to endorse or promote products derived from this software without
//    specific prior written permission.
//
// Disclaimer:
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace Minimal.Utility
{
    /// <summary>
    /// 
    /// </summary>
	public static class FileIO
	{
		// Locking object
		private static readonly object _lock = new object();
        // Standard byte encoding - UTF8
        private static Encoding StandardEncoding = new UTF8Encoding();

		// Lambda function definitions
		private static Func<string, FileStream> openFileRead = x => new FileStream(x, FileMode.Open, FileAccess.Read);
		private static Func<string, FileMode, FileStream> openFileWrite = (x, y) => new FileStream(x, y, FileAccess.Write);
		private static Func<byte[], Encoding, string> encodeBytes = (x, y) => y.GetString(x);
		private static Func<string, Encoding, byte[]> decodeString = (x, y) => y.GetBytes(x);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FileSpec"></param>
        /// <returns></returns>
		public static byte[] readBinaryFile(string FileSpec)
		{
            bool lockTaken = false;
			try
			{
				Monitor.Enter(_lock, ref lockTaken);
				using (FileStream hFile = openFileRead(FileSpec))
				{
                    return StreamUtility.readFullStream(hFile);
				}
			}
			catch (Exception ex)
			{
				throw new Exception("FileIO::readBinaryFile File IO Exception", ex);
			}
			finally
			{
                if (lockTaken) { Monitor.Exit(_lock); }
			}
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FileSpec"></param>
        /// <returns></returns>
        public static string readTextFile(string FileSpec)
        {
            return readTextFile(FileSpec, StandardEncoding);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FileSpec"></param>
        /// <param name="FileEncoding"></param>
        /// <returns></returns>
		public static string readTextFile(string FileSpec, Encoding FileEncoding)
		{
			try
			{
				Monitor.Enter(_lock);
				return encodeBytes(readBinaryFile(FileSpec), FileEncoding);
			}
			catch (Exception ex)
			{
				throw new Exception("FileIO::readTextFile File IO Exception", ex);
			}
			finally
			{
				Monitor.Exit(_lock);
			}
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FileSpec"></param>
        /// <param name="Mode"></param>
        /// <param name="content"></param>
		public static void writeBinaryFile(string FileSpec, FileMode Mode, byte[] content)
		{
			try
			{
				Monitor.Enter(_lock);
				using (FileStream hFile = openFileWrite(FileSpec, Mode))
				{
					hFile.Write(content, 0, content.Length);
				}
			}
			catch (Exception ex)
			{
				throw new Exception("FileIO::writeBinaryFile File IO Exception", ex);
			}
			finally
			{
				Monitor.Exit(_lock);
			}
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FileSpec"></param>
        /// <param name="Mode"></param>
        /// <param name="Content"></param>
        public static void writeTextFile(string FileSpec, FileMode Mode, string Content)
        {
            writeTextFile(FileSpec, Mode, Content, StandardEncoding);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FileSpec"></param>
        /// <param name="Mode"></param>
        /// <param name="Content"></param>
        /// <param name="FileEncoding"></param>
		public static void writeTextFile(string FileSpec, FileMode Mode, string Content, Encoding FileEncoding)
		{
			try
			{
				Monitor.Enter(_lock);
				writeBinaryFile(FileSpec, Mode, decodeString(Content, FileEncoding));
			}
			catch (Exception ex)
			{
				throw new Exception("FileIO::writeTextFile File IO Exception", ex);
			}
			finally
			{
				Monitor.Exit(_lock);
			}
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileSpec"></param>
        /// <param name="secure"></param>
        public static void delete(string fileSpec, bool secure)
        {
            try
            {
                Monitor.Enter(_lock);
                if (File.Exists(fileSpec))
                {
                    if (!secure)
                    {
                        try
                        {
                            File.Delete(fileSpec);
                        }
                        catch (Exception ex)
                        {
                            throw new Exception("FileIO::delete Exception", ex);
                        }
                    }
                    else
                    {
                        using (FileStream hFile = openFileWrite(fileSpec, FileMode.Open))
                        {
                            // Follows DoD standard outlined in DoD Manual 5220.22 M
                            try
                            {
                                // Overwrite with 0s
                                for (long i = 0; i < hFile.Length; i++)
                                {
                                    hFile.WriteByte(0);
                                }
                                hFile.Flush();
                                hFile.Position = 0;

                                // Overwrite with 1s
                                for (long i = 0; i < hFile.Length; i++)
                                {
                                    hFile.WriteByte(1);
                                }
                                hFile.Flush();
                                hFile.Position = 0;

                                // Overwrite with pseudo-random bytes
                                RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
                                for (long i = 0; i < hFile.Length; i++)
                                {
                                    byte[] random = new byte[1];
                                    rng.GetBytes(random);
                                    hFile.WriteByte(random[0]);
                                }
                                hFile.Flush();
                                rng = null;

                                // Now delete the file
                                File.Delete(fileSpec);
                            }
                            catch (Exception ex)
                            {
                                throw new Exception("FileIO::delete Exception (secure delete)", ex);
                            }
                        }
                    }
                }
            }
            finally
            {
                Monitor.Exit(_lock);
            }
        }
    }
}
