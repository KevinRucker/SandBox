﻿// Author: Kevin Rucker
// License: BSD 3-Clause
// Copyright (c) 2014, Kevin Rucker
// All rights reserved.

// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice,
//    this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors
//    may be used to endorse or promote products derived from this software without
//    specific prior written permission.
//
// Disclaimer:
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

using Minimal.Compression;
using Minimal.Data;
using Minimal.Interfaces;
using Minimal.Network;
using Minimal.Security.Encryption;
using Minimal.Utility;
using System.Collections.Generic;

namespace Minimal.Common
{
    /// <summary>
    /// Library object factory
    /// </summary>
    public static class Factory
    {
        /// <summary>
        /// Creates an instance of a <see cref="BinaryHeader"/> object
        /// </summary>
        /// <returns>Object which implements <see cref="IBinaryHeader"/></returns>
        public static IBinaryHeader CreateBinaryHeader()
        {
            return BinaryHeader.Factory();
        }

        /// <summary>
        /// Creates an instance of a <see cref="BinaryHeader"/> object
        /// </summary>
        /// <param name="entryGraph">Graph of objects which implement <code>IHeaderEntry</code></param>
        /// <returns>Object which implements <see cref="IBinaryHeader"/></returns>
        public static IBinaryHeader CreateBinaryHeader(IList<IHeaderEntry> entryGraph)
        {
            return BinaryHeader.Factory(entryGraph);
        }

        /// <summary>
        /// Creates an instance of a <see cref="BinaryHeader"/> object
        /// </summary>
        /// <param name="bytes"><code>byte[]</code> containing a <code>BinaryHeader</code></param>
        /// <param name="entryGraph">Graph of objects which implement <code>IHeaderEntry</code></param>
        /// <returns>Object which implements <see cref="IBinaryHeader"/></returns>
        public static IBinaryHeader CreateBinaryHeader(byte[] bytes, IList<IHeaderEntry> entryGraph)
        {
            return BinaryHeader.Factory(bytes, entryGraph);
        }

        /// <summary>
        /// Creates an instance of a <see cref="HeaderEntry"/> object
        /// </summary>
        /// <returns>Object which implements <see cref="IHeaderEntry"/></returns>
        public static IHeaderEntry CreateHeaderEntry()
        {
            return HeaderEntry.Factory();
        }

        /// <summary>
        /// Creates an instance of a <see cref="HeaderEntry"/> object
        /// </summary>
        /// <param name="name">Name of the <see cref="HeaderEntry"/></param>
        /// <param name="value">Value of the <see cref="HeaderEntry"/></param>
        /// <returns>Object which implements <see cref="IHeaderEntry"/></returns>
        public static IHeaderEntry CreateHeaderEntry(string name, object value)
        {
            return HeaderEntry.Factory(name, value);
        }

        /// <summary>
        /// Creates an instance of a <see cref="DataContainer"/> object
        /// </summary>
        /// <returns>Object which implements <see cref="IDataContainer"/></returns>
        public static IDataContainer CreateDataContainer()
        {
            return DataContainer.Factory();
        }

        /// <summary>
        /// Creates an instance of a <see cref="DataContainer"/> object
        /// </summary>
        /// <param name="data"><code>byte[]</code> containing the data</param>
        /// <param name="headerdef">A list of <see cref="HeaderEntry"/> objects</param>
        /// <returns>Object which implements <see cref="IDataContainer"/></returns>
        public static IDataContainer CreateDataContainer(byte[] data, IList<IHeaderEntry> headerdef)
        {
            return DataContainer.Factory(data, headerdef);
        }

        /// <summary>
        /// Creates an instance of a <see cref="DBConfigFileCSProvider"/> object
        /// </summary>
        /// <param name="ConnectionStringName"></param>
        /// <param name="encrypted"></param>
        /// <returns>Object which implements <see cref="IDBConnectionStringProvider"/></returns>
        public static IDBConnectionStringProvider CreateConfigFileCSProvider(string ConnectionStringName, bool encrypted)
        {
            return DBConfigFileCSProvider.Factory(ConnectionStringName, encrypted);
        }

        /// <summary>
        /// Creates an instance of a <see cref="DBContext"/> object
        /// </summary>
        /// <param name="provider">Enumeration - <see cref="DataProviders"/></param>
        /// <param name="CSProvider">Object which implements <see cref="IDBConnectionStringProvider"/></param>
        /// <returns>Object which implements <see cref="IDBContext"/></returns>
        public static IDBContext CreateDBContext(DataProviders provider, IDBConnectionStringProvider CSProvider)
        {
            return DBContext.Factory(provider, CSProvider);
        }

        /// <summary>
        /// Creates an instance of a <see cref="SqlDirect"/> object
        /// </summary>
        /// <param name="context">Object which implements <see cref="IDBContext"/></param>
        /// <returns>An instance of <see cref="SqlDirect"/> object</returns>
        public static SqlDirect CreateSqlDirect(IDBContext context)
        {
            return SqlDirect.Factory(context);
        }

        /// <summary>
        /// Creates an instance of a <see cref="SMTP"/> (Simple Mail Transfer Protocol) object
        /// </summary>
        /// <returns>Object which implements <see cref="ISMTP"/></returns>
        public static ISMTP CreateSMTP()
        {
            return SMTP.SMTPFactory();
        }

        /// <summary>
        /// Creates an instance of a <see cref="WebHeaderCollectionBuilder"/> object
        /// </summary>
        /// <returns>An instance of a <see cref="WebHeaderCollectionBuilder"/> object</returns>
        public static WebHeaderCollectionBuilder CreateWebHeaderCollectionBuilder()
        {
            return WebHeaderCollectionBuilder.Factory();
        }

        /// <summary>
        /// Creates an instance of an <see cref="AESEncryptionProvider"/> object
        /// </summary>
        /// <returns>Object which implements <see cref="IEncryptionProvider"/></returns>
        public static IEncryptionProvider CreateAesEncryptionProvider()
        {
            return AESEncryptionProvider.Factory();
        }

        /// <summary>
        /// Creates an instance of an <see cref="TripleDESEncryptionProvider"/> object
        /// </summary>
        /// <returns>Object which implements <see cref="IEncryptionProvider"/></returns>
        public static IEncryptionProvider CreateTripleDESEncryptionProvider()
        {
            return TripleDESEncryptionProvider.Factory();
        }

        /// <summary>
        /// Creates an instance of a <see cref="BitMask"/> object
        /// </summary>
        /// <returns>Object which implements <see cref="IBitMask"/></returns>
        public static IBitMask CreateBitMask()
        {
            return BitMask.Factory();
        }

        /// <summary>
        /// Creates an instance of a <see cref="BitMask"/> object
        /// </summary>
        /// <param name="baseValue"><code>ulong</code> containing the base value for the <see cref="BitMask"/> object</param>
        /// <returns>Object which implements <see cref="IBitMask"/></returns>
        public static IBitMask CreateBitMask(ulong baseValue)
        {
            return BitMask.Factory(baseValue);
        }

        /// <summary>
        /// Creates an instance of <see cref="CompressionProvider"/> object
        /// </summary>
        /// <returns>Object which implements <see cref="ICompressionProvider"/></returns>
        public static ICompressionProvider CreateCompressionProvider()
        {
            return CompressionProvider.Factory();
        }
    }
}
