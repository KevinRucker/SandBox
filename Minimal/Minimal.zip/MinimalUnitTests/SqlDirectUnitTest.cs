﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Minimal.Common;
using Minimal.Data;
using Minimal.Interfaces;
using System.Collections.Generic;
using System.Data;

namespace MinimalUnitTests
{
    [TestClass]
    public class SqlDirectUnitTest
    {
        private IDBContext _context;
        private SqlDirect _sql;

        [TestInitialize]
        public void init()
        {
            _context = Factory.CreateDBContext(
                    DataProviders.SqlServer, 
                    Factory.CreateConfigFileCSProvider("TestConnection2", true));
            _sql = Factory.CreateSqlDirect(_context);
        }

        [TestMethod]
        public void SqlDirect_ScalarTest()
        {
            var query = "SELECT COUNT(*) FROM aspnet_SchemaVersions";
            var count = _sql.Scalar<int>(query, CommandType.Text, null);
            Assert.IsTrue(count > 0);
        }

        [TestMethod]
        public void SqlDirect_DataSetTest()
        {
            var query = "SELECT * FROM aspnet_SchemaVersions";
            var ds = _sql.Query(query, CommandType.Text, null);
            Assert.IsTrue(ds.Tables.Count > 0);
            Assert.IsTrue(ds.Tables[0].Rows.Count > 0);
        }

        [TestMethod]
        public void SqlDirect_DataReaderTest()
        {
            var query = "SELECT * FROM aspnet_SchemaVersions";
            var connection = _sql.GetConnection();
            try
            {
                using (var reader = _sql.Query(query, CommandType.Text, null, ref connection))
                {
                    Assert.IsTrue(reader.Read());
                }
            }
            finally
            {
                if (connection.State != ConnectionState.Closed) { connection.Close(); }
                connection.Dispose();
                connection = null;
            }
        }

        [TestMethod]
        public void SqlDirect_StoredProcedureTest()
        {
            var sproc = "aspnet_CheckSchemaVersion";
            var parameters = new List<IDbDataParameter>();
            parameters.Add(_context.CreateParameter(DbType.String, ParameterDirection.Input, "@Feature", null, null, null, null, DataRowVersion.Proposed, "common"));
            parameters.Add(_context.CreateParameter(DbType.String, ParameterDirection.Input, "@CompatibleSchemaVersion", null, null, null, null, DataRowVersion.Proposed, "1"));
            var result = _sql.Scalar<int>(sproc, CommandType.StoredProcedure, parameters);
            Assert.IsTrue(result == 0 || result == 1);
        }

        [TestMethod]
        public void SqlDirect_ParameterizedQueryTest()
        {
            var query = "SELECT IsCurrentVersion FROM aspnet_SchemaVersions WHERE Feature = @Feature AND CompatibleSchemaVersion = @CompatibleSchemaVersion";
            var parameters = new List<IDbDataParameter>();
            parameters.Add(_context.CreateParameter(DbType.String, ParameterDirection.Input, "@Feature", null, null, null, null, DataRowVersion.Proposed, "common"));
            parameters.Add(_context.CreateParameter(DbType.String, ParameterDirection.Input, "@CompatibleSchemaVersion", null, null, null, null, DataRowVersion.Proposed, "1"));
            var result = _sql.Scalar<bool>(query, CommandType.Text, parameters);
            Assert.IsTrue(result);
        }
    }
}
