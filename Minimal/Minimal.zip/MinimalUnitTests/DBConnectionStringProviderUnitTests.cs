﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Minimal.Common;
using Minimal.Interfaces;

namespace MinimalUnitTests
{
    [TestClass]
    public class DBConnectionStringProviderUnitTests
    {
        private string origin = string.Empty;

        [TestInitialize]
        public void TestInit()
        {
            origin = TestDataFactory.GetDBConnectionString();
        }

        [TestMethod]
        public void DBConnectionStringProvider_ConstructorTest()
        {
            IDBConnectionStringProvider csp = null;
            csp = Factory.CreateConfigFileCSProvider("TestConnection1", false);
            Assert.IsNotNull(csp);
        }

        [TestMethod]
        public void DBConnectionStringProvider_GetConnectionStringTest()
        {
            IDBConnectionStringProvider csp = Factory.CreateConfigFileCSProvider("TestConnection1", false);
            string target = csp.GetConnectionString();
            Assert.AreEqual(origin, target);
        }

        [TestMethod]
        public void DBConnectionStringProvider_GetEncryptedConnectionStringTest()
        {
            IDBConnectionStringProvider csp = Factory.CreateConfigFileCSProvider("TestConnection2", true);
            string target = csp.GetConnectionString();
            Assert.AreEqual(origin, target);
        }
    }
}
