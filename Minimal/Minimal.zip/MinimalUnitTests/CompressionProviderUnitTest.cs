﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Minimal.Common;
using Minimal.Interfaces;
using System;

namespace MinimalUnitTests
{
    [TestClass]
    public class CompressionProviderUnitTest
    {
        private string _origin_string = string.Empty;
        private byte[] _origin_bytes = null;
        private int _size = 0x400; // 1KB

        [TestInitialize]
        public void TestInit()
        {
            if (string.IsNullOrEmpty(_origin_string))
            {
                _origin_string = TestDataFactory.GetLoremIpsumString(_size, new System.Text.UTF8Encoding());
                _origin_bytes = TestDataFactory.GetLoremIpsumBytes(_size);
            }
        }

        [TestMethod]
        public void CompressionProvider_ConstructorTest()
        {
            ICompressionProvider cp = null;
            cp = Factory.CreateCompressionProvider();
            Assert.IsNotNull(cp);
        }

        [TestMethod]
        public void CompressionProvider_CompressDecompressStringTest()
        {
            Int32 origin_size = _origin_string.Length;
            ICompressionProvider cp = Factory.CreateCompressionProvider();
            byte[] target1 = cp.compressString(_origin_string);
            Int32 compressed_size = target1.Length;
            string target2 = cp.decompressString(target1);
            Assert.IsTrue(origin_size > compressed_size, "Compressed size is greater than uncompressed size.");
            Assert.AreEqual(_origin_string, target2, "Decompressed string was not equal to original string.");
        }

        [TestMethod]
        public void CompressionProvider_CompressDecompressBytesTest()
        {
            Int32 origin_size = _origin_bytes.Length;
            ICompressionProvider cp = Factory.CreateCompressionProvider();
            byte[] target1 = cp.compressBytes(_origin_bytes);
            Int32 compressed_size = target1.Length;
            byte[] target2 = cp.decompressBytes(target1);
            Assert.IsTrue(origin_size > compressed_size, "Compressed size is greater than uncompressed size.");
            Assert.AreEqual(Convert.ToBase64String(_origin_bytes), Convert.ToBase64String(target2), "Decompressed byte array was not equal to original byte array.");
        }
    }
}
