﻿// Author: Kevin Rucker
// License: BSD 3-Clause
// Copyright (c) 2014, Kevin Rucker
// All rights reserved.

// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice,
//    this list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
//
// 3. Neither the name of the copyright holder nor the names of its contributors
//    may be used to endorse or promote products derived from this software without
//    specific prior written permission.
//
// Disclaimer:
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
// IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
// INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
// EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Minimal.Common;
using Minimal.Interfaces;
using Minimal.Utility;

namespace Minimal.Security.Encryption
{
    /// <summary>
    /// Concrete implementation of AES256 EncryptionProvider
    /// </summary>
    public class AESEncryptionProvider : IEncryptionProvider
    {
        private Encoding StandardEncoding = new UTF8Encoding();
        private Func<byte[], string> BytesToB64 = x => Convert.ToBase64String(x);
        private Func<string, byte[]> B64ToBytes = x => Convert.FromBase64String(x);
        private Func<Encoding, byte[], string> DecodeBytes = (x, y) => x.GetString(y);
        private Func<Encoding, string, byte[]> EncodeString = (x, y) => x.GetBytes(y);

        /// <summary>
        /// Private constructor prevents direct instantiation
        /// </summary>
        private AESEncryptionProvider()
        {

        }

        /// <summary>
        /// Factory method
        /// </summary>
        /// <returns><code>AESEncryptionProvider</code></returns>
        public static IEncryptionProvider Factory()
        {
            return new AESEncryptionProvider();
        }

        /// <summary>
        /// Encrypts a <code>System.String</code> using the provided passphrase to generate the Key and IV
        /// </summary>
        /// <param name="passphrase"><code>System.String</code> passphrase to use</param>
        /// <param name="value"><code>System.String</code> value to encrypt</param>
        /// <returns>base64 encoded encrypted <code>System.String</code></returns>
        public string EncryptString(string passphrase, string value)
        {
            return BytesToB64(EncryptBytes(passphrase, EncodeString(StandardEncoding, value)));
        }

        /// <summary>
        /// Decrypts an encrypted, base64 encoded <code>System.String</code> using the provided passphrase to generate the Key and IV
        /// </summary>
        /// <param name="passphrase"><code>System.String</code> passphrase to use</param>
        /// <param name="value">base64 encoded, encrypted <code>System.String</code> to decrypt</param>
        /// <returns>Decrypted <code>System.String</code></returns>
        public string DecryptString(string passphrase, string value)
        {
            return DecodeBytes(StandardEncoding, DecryptBytes(passphrase, B64ToBytes(value)));
        }

        /// <summary>
        /// Encrypts a <code>System.byte[]</code> using the provided passphrase to generate the Key and IV
        /// </summary>
        /// <param name="passphrase"><code>System.String</code> passphrase to use</param>
        /// <param name="value"><code>System.byte[]</code> data to encrypt</param>
        /// <returns>Encrypted <code>System.byte[]</code></returns>
        public byte[] EncryptBytes(string passphrase, byte[] value)
        {
            using (var CSP = new AesCryptoServiceProvider())
            {
                using (var Encryptor = CSP.CreateEncryptor(
                    Digest.getKeyFromPassPhrase(passphrase, CSP.KeySize / 8),
                    Digest.getIVFromPassPhrase(passphrase, CSP.BlockSize / 8)))
                {
                    using (var msEncrypt = new MemoryStream())
                    {
                        using (var csEncrypt = new CryptoStream(msEncrypt, Encryptor, CryptoStreamMode.Write))
                        {
                            csEncrypt.Write(value, 0, value.Length);
                            csEncrypt.FlushFinalBlock();
                            var container = Common.Factory.CreateDataContainer();
                            var headerdef = new List<IHeaderEntry>();
                            headerdef.Add(Common.Factory.CreateHeaderEntry("OriginalDataSize", value.Length));
                            container.Header = Common.Factory.CreateBinaryHeader(headerdef);
                            container.Data = msEncrypt.ToArray();
                            return container.GetBytes();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Decrypts an encrypted <code>System.byte[]</code>
        /// </summary>
        /// <param name="passphrase"><code>System.String</code> passphrase to use</param>
        /// <param name="value"><code>System.byte[]</code> data to decrypt</param>
        /// <returns>Decrypted <code>System.byte[]</code></returns>
        public byte[] DecryptBytes(string passphrase, byte[] value)
        {
            using (var CSP = new AesCryptoServiceProvider())
            {
                using (var Decryptor = CSP.CreateDecryptor(
                    Digest.getKeyFromPassPhrase(passphrase, CSP.KeySize / 8),
                    Digest.getIVFromPassPhrase(passphrase, CSP.BlockSize / 8)))
                {
                    var headerdef = new List<IHeaderEntry>();
                    headerdef.Add(Common.Factory.CreateHeaderEntry("OriginalDataSize", default(int)));
                    var container = Common.Factory.CreateDataContainer(value, headerdef);
                    using (var msDecrypt = new MemoryStream(container.Data))
                    {
                        using (var csDecrypt = new CryptoStream(msDecrypt, Decryptor, CryptoStreamMode.Read))
                        {
                            var buffer = (byte[])Array.CreateInstance(typeof(byte), msDecrypt.Length);
                            csDecrypt.Read(buffer, 0, buffer.Length);
                            var result = new byte[(int)container.Header["OriginalDataSize"].entryvalue];
                            Buffer.BlockCopy(buffer, 0, result, 0, result.Length);
                            return result;
                        }
                    }
                }
            }
        }
    }
}
