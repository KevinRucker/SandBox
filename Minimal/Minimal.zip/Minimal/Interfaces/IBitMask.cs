﻿using System;

namespace Minimal.Interfaces
{
    /// <summary>
    /// The interface for BitMap class implementations
    /// </summary>
    public interface IBitMask
    {
        /// <summary>
        /// The base value of the bitmap
        /// </summary>
        UInt64 baseValue { get; set; }
        /// <summary>
        /// Get the value of the bit at the supplied position position in the bitmask
        /// </summary>
        /// <param name="bitPosition"></param>
        /// <returns><code>true</code> if the bit is on and <code>false</code> if it is off</returns>
        bool getBitValue(Int32 bitPosition);
        /// <summary>
        /// Turn on bit at the supplied position in the bitmask
        /// </summary>
        /// <param name="bitPosition"></param>
        void setBit(Int32 bitPosition);
        /// <summary>
        /// Turn off bit at the supplied position in the bitmask
        /// </summary>
        /// <param name="bitPosition"></param>
        void clearBit(Int32 bitPosition);
        /// <summary>
        /// Turn on all bits in the bitmask
        /// </summary>
        void setAll();
        /// <summary>
        /// Turn off all bits in the bitmask
        /// </summary>
        void clearAll();
    }
}
