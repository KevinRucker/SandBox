﻿namespace Minimal.Interfaces
{
    /// <summary>
    /// Interface for CompressionProvider implementations
    /// </summary>
    public interface ICompressionProvider
    {
        /// <summary>
        /// Compress a <code>string</code> value
        /// </summary>
        /// <param name="value"><code>string</code> to compress</param>
        /// <returns><code>byte[]</code></returns>
        byte[] compressString(string value);
        /// <summary>
        /// Decompress a <code>byte[]</code>
        /// </summary>
        /// <param name="value">The <code>byte[]</code> to decompress.</param>
        /// <returns><code>string</code></returns>
        string decompressString(byte[] value);
        /// <summary>
        /// Compress <code>byte[]</code>
        /// </summary>
        /// <param name="value"><code>byte[]</code> to compress</param>
        /// <returns><code>byte[]</code></returns>
        byte[] compressBytes(byte[] value);
        /// <summary>
        /// Decompress <code>byte[]</code>
        /// </summary>
        /// <param name="value"><code>byte[]</code> to decompress</param>
        /// <returns><code>byte[]</code></returns>
        byte[] decompressBytes(byte[] value);
    }
}
