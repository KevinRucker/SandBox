﻿using System;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Minimal.Interfaces;
using Minimal.Common;

namespace MinimalUnitTests
{
    [TestClass]
    public class EncryptionProviderUnitTests
    {
        private string origin = string.Empty;
        private string passphrase = string.Empty;

        [TestInitialize]
        public void TestInit()
        {
            origin = TestDataFactory.GetFillerText();
            passphrase = "t3stP4ss!";
        }

        [TestMethod]
        public void AESEncryptionProvider_ConstructorTest()
        {
            IEncryptionProvider ep = null;
            ep = Factory.CreateAesEncryptionProvider();
            Assert.IsNotNull(ep);
        }

        [TestMethod]
        public void AESEncryptionProvider_StringsTest()
        {
            var ep = Factory.CreateAesEncryptionProvider();
            var target1 = ep.EncryptString(passphrase, origin);
            var target2 = ep.DecryptString(passphrase, target1);
            Assert.AreNotEqual(origin, target1);
            Assert.AreEqual(origin, target2);
        }

        [TestMethod]
        public void AESEncryptionProvider_BytesTest()
        {
            var test = (byte[])Array.CreateInstance(typeof(byte), new UTF8Encoding().GetByteCount(origin));
            test = new UTF8Encoding().GetBytes(origin);
            var ep = Factory.CreateAesEncryptionProvider();
            var target1 = ep.EncryptBytes(passphrase, test);
            var target2 = ep.DecryptBytes(passphrase, target1);
            var final = new UTF8Encoding().GetString(target2);
            Assert.AreEqual(origin, final);
        }

        [TestMethod]
        public void TripleDESEncryptionProvider_ConstructorTest()
        {
            IEncryptionProvider ep = null;
            ep = Factory.CreateTripleDESEncryptionProvider();
            Assert.IsNotNull(ep);
        }

        [TestMethod]
        public void TripleDESEncryptionProvider_StringsTest()
        {
            var ep = Factory.CreateTripleDESEncryptionProvider();
            var target1 = ep.EncryptString(passphrase, origin);
            var target2 = ep.DecryptString(passphrase, target1);
            Assert.AreNotEqual(origin, target1);
            Assert.AreEqual(origin, target2);
        }

        [TestMethod]
        public void TripleDESEncryptionProvider_BytesTest()
        {
            var test = (byte[])Array.CreateInstance(typeof(byte), new UTF8Encoding().GetByteCount(origin));
            test = new UTF8Encoding().GetBytes(origin);
            var ep = Factory.CreateTripleDESEncryptionProvider();
            var target1 = ep.EncryptBytes(passphrase, test);
            var target2 = ep.DecryptBytes(passphrase, target1);
            var final = new UTF8Encoding().GetString(target2);
            Assert.AreEqual(origin, final);
        }
    }
}
