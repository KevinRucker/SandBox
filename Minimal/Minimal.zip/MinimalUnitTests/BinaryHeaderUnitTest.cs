﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Minimal.Common;
using Minimal.Interfaces;
using System;
using System.Collections.Generic;

namespace MinimalUnitTests
{
    [TestClass]
    public class BinaryHeaderUnitTest
    {
        [TestMethod]
        public void BinaryHeader_ConstructorTest()
        {
            IBinaryHeader header = null;
            header = Factory.CreateBinaryHeader();
            Assert.IsNotNull(header);
        }

        [TestMethod]
        public void BinaryHeader_ParameterizedConstructorTest()
        {
            IBinaryHeader header = null;
            IList<IHeaderEntry> TestEntries = new List<IHeaderEntry>();
            TestEntries.Add(Factory.CreateHeaderEntry("entry1", (byte)1));
            TestEntries.Add(Factory.CreateHeaderEntry("entry2", (short)2));
            TestEntries.Add(Factory.CreateHeaderEntry("entry3", (int)3));
            header = Factory.CreateBinaryHeader(TestEntries);
            Assert.IsNotNull(header);
            Assert.AreEqual((byte)1, header["entry1"].entryvalue);
            Assert.AreEqual((short)2, header["entry2"].entryvalue);
            Assert.AreEqual((int)3, header["entry3"].entryvalue);
        }

        [TestMethod]
        public void BinaryHeader_FunctionalTest()
        {
            IList<IHeaderEntry> TestEntries1 = new List<IHeaderEntry>();
            TestEntries1.Add(Factory.CreateHeaderEntry("entry1", (byte)1));
            TestEntries1.Add(Factory.CreateHeaderEntry("entry2", (short)2));
            TestEntries1.Add(Factory.CreateHeaderEntry("entry3", (int)3));
            BinaryHeader header1 = (BinaryHeader)Factory.CreateBinaryHeader(TestEntries1);
            byte[] bytes1 = new byte[header1.Size];
            bytes1 = header1.HeaderBytes();

            IList<IHeaderEntry> TestEntries2 = new List<IHeaderEntry>();
            TestEntries2.Add(Factory.CreateHeaderEntry("entry1", default(byte)));
            TestEntries2.Add(Factory.CreateHeaderEntry("entry2", default(short)));
            TestEntries2.Add(Factory.CreateHeaderEntry("entry3", default(int)));
            BinaryHeader header2 = (BinaryHeader)Factory.CreateBinaryHeader(bytes1, TestEntries2);
            byte[] bytes2 = new byte[header2.Size];
            bytes2 = header2.HeaderBytes();

            byte entry1 = (byte)header2["entry1"].entryvalue;
            short entry2 = (short)header2["entry2"].entryvalue;
            int entry3 = (int)header2["entry3"].entryvalue;

            Assert.AreEqual(Convert.ToBase64String(bytes1), Convert.ToBase64String(bytes2));
        }
    }
}
